#!/bin/sh
set -eu

BASE=/data/local/tmp/c3-screen-stream-v2
FPS=${FPS:-30}
BITRATE=${BITRATE:-4500000}

sudo -n "$BASE/bin/sde_rotator_stream" "$FPS" 2>>"$BASE/capture.log" \
  | "$BASE/bin/swscale_xrgb_to_nv12" 2>>"$BASE/convert.log" \
  | sudo -n "$BASE/bin/v4l_h264_encoder" 1024 512 "$FPS" "$BITRATE" tcp \
      2>>"$BASE/encoder.log"
