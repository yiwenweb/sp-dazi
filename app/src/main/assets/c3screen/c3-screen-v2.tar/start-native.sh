#!/bin/sh
# ============================================================
# start-native.sh —— C3 投屏管线启动脚本
#
# 三段管道：
#   sde_rotator_stream  ->  swscale_xrgb_to_nv12  ->  v4l_h264_encoder
#
# 环境变量：
#   FPS        帧率（默认 30，install.sh 传 20）
#   BITRATE    码率（默认 4500000，install.sh 传 5000000）
#   ROT_MODE   自研 rotator 的 buffer 模式（默认 --mode=dmabuf）
#              可选 --mode=dmabuf / --mode=mmap
#
# 说明：本脚本刻意【不使用 set -e】。管道中任一段失败时，
# 我们更需要看到各段自己的 stderr 落盘，而不是脚本静默退出。
# ============================================================
set -u

BASE=/data/local/tmp/c3-screen-stream-v2
FPS=${FPS:-30}
BITRATE=${BITRATE:-4500000}
ROT_MODE=${ROT_MODE:---mode=dmabuf}

ROT=$BASE/bin/sde_rotator_stream
SW=$BASE/bin/swscale_xrgb_to_nv12
ENC=$BASE/bin/v4l_h264_encoder

# 每轮启动在 capture.log 留一个分隔标记，便于区分批次
{
  echo "=== start-native.sh ==="
  echo "FPS=$FPS BITRATE=$BITRATE ROT_MODE=$ROT_MODE"
} >>"$BASE/capture.log" 2>/dev/null

# ── 前置检查一：三个二进制存在且可执行 ──
for f in "$ROT" "$SW" "$ENC"; do
  if [ ! -x "$f" ]; then
    echo "预检失败：$f 不存在或不可执行" >>"$BASE/capture.log"
    exit 1
  fi
done

# ── 前置检查二：rotator 能否被 exec（--help 立即返回，不碰设备）──
# 这一步把「二进制无法执行」与「设备 ioctl 失败」彻底分开。
HELP=$(sudo -n "$ROT" --help 2>&1)
HRC=$?
{
  echo "--- rotator 预检 rc=$HRC ---"
  echo "$HELP" | head -6
} >>"$BASE/capture.log" 2>/dev/null
if [ "$HRC" -ne 0 ]; then
  echo "预检失败：rotator 无法执行（rc=$HRC），见上方输出" >>"$BASE/capture.log"
  exit 2
fi

# ── 正式启动三段管道 ──
sudo -n "$ROT" "$FPS" "$ROT_MODE" 2>>"$BASE/capture.log" \
  | "$SW" 2>>"$BASE/convert.log" \
  | sudo -n "$ENC" 1024 512 "$FPS" "$BITRATE" tcp 2>>"$BASE/encoder.log"

rc=$?
{
  echo "--- 管道退出码=$rc ---"
  echo "rotator: $(pgrep -f 'bin/sde_rotator_stream' | tr '\n' ' ')"
  echo "swscale: $(pgrep -f 'bin/swscale_xrgb_to_nv12' | tr '\n' ' ')"
  echo "encoder: $(pgrep -f 'bin/v4l_h264_encoder' | tr '\n' ' ')"
} >>"$BASE/capture.log" 2>/dev/null
exit 0
