#!/bin/sh
set -eu

BASE=/data/local/tmp/c3-screen-stream-v2
FPS=${FPS:-30}
BITRATE=${BITRATE:-4500000}
# 自研版 sde_rotator_stream（= sde_rotator_stream2）的 buffer 导入模式：
#   --mode=dmabuf  推荐。V4L2_MEMORY_DMABUF + m.fd，
#                  修正第三方把 dma-buf fd 塞进 m.userptr 的缺陷。
#   --mode=mmap    兜底。VIDIOC_REQBUFS + QUERYBUF + mmap(video fd)。
# 若 dmabuf 在实机上不通，把下面这行改成 ROT_MODE=--mode=mmap 即可回退。
ROT_MODE=${ROT_MODE:---mode=dmabuf}

sudo -n "$BASE/bin/sde_rotator_stream" "$FPS" "$ROT_MODE" 2>>"$BASE/capture.log" \
  | "$BASE/bin/swscale_xrgb_to_nv12" 2>>"$BASE/convert.log" \
  | sudo -n "$BASE/bin/v4l_h264_encoder" 1024 512 "$FPS" "$BITRATE" tcp \
      2>>"$BASE/encoder.log"
