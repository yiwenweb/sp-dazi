/*
 * sde_rotator_stream2.c —— 自研版「屏幕旋转采集」工具
 * ====================================================
 *
 * 背景 / 目的
 * -----------
 * 第三方 c3-screen-stream-v2 的 sde_rotator_stream 在 C3 上首帧即失败：
 *   rotator frame error flags=0x4040   (V4L2_BUF_FLAG_ERROR)
 *   exit(17)，输出 0 字节
 *
 * 逆向结论（详见 逆向分析报告.md）：
 *   该程序把 ION 导出 dma-buf 后 mmap 得到用户态虚拟地址，
 *   但 VIDIOC_QBUF 时把 dma-buf 的 **fd（小整数）** 填进了 m.userptr，
 *   且 memory 字段未设为 V4L2_MEMORY_DMABUF。
 *   驱动按 userptr 语义去 SMMU 映射这个伪地址 → 必然失败。
 *
 * 本程序的做法
 * ------------
 *   走标准、正确的 V4L2 dma-buf 导入路径：
 *     - 源: 从 DRM 找 1080x2160x32 的 scanout framebuffer，
 *           PRIME_HANDLE_TO_FD 导出为 dma-buf fd
 *     - 目标: ION 分配 → ION_IOC_SHARE 得到 dma-buf fd
 *     - 两者都用 V4L2_MEMORY_DMABUF + m.fd 入队
 *   并通过 --mode 参数支持多种策略，便于在设备上实测哪种可用：
 *     dmabuf   : 源/目标都用 V4L2_MEMORY_DMABUF（默认，推荐）
 *     ionread  : 目标用 ION+DMABUF，源用 DRM fb 的 dma-buf
 *     mmap     : 让驱动自己分配 buffer（VIDIOC_REQBUFS + MMAP），纯标准路径
 *
 * 输出
 * ----
 *   stdout: 目标 buffer 的 NV12/XRGB 原始数据（供下游 swscale 转换）
 *   stderr: 日志（与第三方格式兼容，便于沿用现有管道）
 *
 * 用法
 * ----
 *   sde_rotator_stream2 [FPS] [--mode=dmabuf|mmap|ionread] [--width=W] [--height=H]
 *   sde_rotator_stream2 20
 *   sde_rotator_stream2 20 --mode=mmap
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <linux/videodev2.h>

/* ============================================================
 * 1. 常量与结构定义
 * ============================================================ */

/*
 * 像素格式（fourcc）
 * -----------------
 * 逆向结论：源 = "QRGB" (0x42475251)，目标 = "XR24" (0x34325258)。
 * 这两个在标准 linux/videodev2.h 里没有对应宏，必须自算。
 * v4l2 的 pixelformat 是 u32，四字码以小端存储：
 *   fourcc('Q','R','G','B') = 'Q' | 'R'<<8 | 'G'<<16 | 'B'<<24
 */
#define fourcc(a,b,c,d)  ((uint32_t)(a) | ((uint32_t)(b) << 8) | \
                          ((uint32_t)(c) << 16) | ((uint32_t)(d) << 24))

#define FMT_QRGB    fourcc('Q','R','G','B')   /* 0x42475251  源，高通 XRGB8888 */
#define FMT_XR24    fourcc('X','R','2','4')   /* 0x34325258  目标，DRM_FORMAT_XRGB8888 */

#define DEV_CARD0   "/dev/dri/card0"
#define DEV_VIDEO   "/dev/video2"
#define DEV_ION     "/dev/ion"

/* 源：C3 的扫描输出分辨率 */
#define SRC_W       1080
#define SRC_H       2160
#define SRC_FOURCC  FMT_QRGB

/* 目标：旋转 90 度后的中间格式，交由下游 swscale 缩放到 1024x512 */
#define DST_W       1080
#define DST_H       540
#define DST_FOURCC  FMT_XR24

#define NUM_BUFS    2

/* ---- ION ioctl（Android 内核头未随 SDK 提供，此处内联定义） ---- */
#define ION_IOC_MAGIC       'I'

struct ion_handle;
struct ion_handle_data_ { struct ion_handle *handle; };

struct ion_allocation_data {
    size_t          len;
    size_t          align;
    unsigned int    heap_id_mask;
    unsigned int    flags;
    struct ion_handle *handle;
};

struct ion_fd_data {
    struct ion_handle *handle;
    int             fd;
};

struct ion_heap_data {
    char            name[16];
    unsigned int    type;
    unsigned int    heap_id;
    unsigned int    reserved0;
    unsigned int    reserved1;
    unsigned int    reserved2;
};

struct ion_heap_query {
    unsigned int    cnt;
    unsigned int    reserved0;
    uint64_t        heaps;
    unsigned int    reserved1;
    unsigned int    reserved2;
    unsigned int    reserved3;
};

#define ION_IOC_ALLOC       _IOWR(ION_IOC_MAGIC, 0, struct ion_allocation_data)
#define ION_IOC_FREE        _IOWR(ION_IOC_MAGIC, 1, struct ion_handle_data_)
#define ION_IOC_SHARE       _IOWR(ION_IOC_MAGIC, 4, struct ion_fd_data)
#define ION_IOC_HEAP_QUERY  _IOWR(ION_IOC_MAGIC, 8, struct ion_heap_query)

/* ---- DRM ioctl ----
 *
 * !! 重要 !!
 * 以下命令码 **硬编码为设备上实测值**，不可用 _IOWR 宏重新计算。
 * 实测（逆向 sde_rotator_stream 反汇编）得到的 size 字段与 64 位结构体
 * 实际大小不一致，例如：
 *   GETRESOURCES        size=16  vs struct 实际 64 字节
 *   PRIME_HANDLE_TO_FD  size=28  vs struct 实际 12 字节
 * 这是该内核 drm 头的历史遗留定义。若用 _IOWR 现算，_IOC_SIZE 不匹配
 * 会被内核直接拒绝（-EINVAL）。
 */
#define DRM_IOCTL_MODE_GETRESOURCES      0xc01064b5u
#define DRM_IOCTL_MODE_GETCRTC           0xc02064b6u
#define DRM_IOCTL_MODE_GETPLANE          0xc00c642du
#define DRM_IOCTL_PRIME_HANDLE_TO_FD     0xc01c64adu
#define DRM_IOCTL_GEM_CLOSE              0x40086409u

struct drm_mode_card_res {
    uint64_t fb_id_ptr;
    uint64_t crtc_id_ptr;
    uint64_t connector_id_ptr;
    uint64_t encoder_id_ptr;
    uint32_t count_fbs;
    uint32_t count_crtcs;
    uint32_t count_connectors;
    uint32_t count_encoders;
    uint32_t min_width,  max_width;
    uint32_t min_height, max_height;
};

struct drm_mode_get_crtc {
    uint64_t set_connectors_ptr;
    uint32_t count_connectors;
    uint32_t crtc_id;
    uint32_t fb_id;
    uint32_t x, y;
    uint32_t gamma_size;
    uint32_t mode_valid;
    uint32_t mode_clock;
    uint16_t mode_hdisplay;
    uint16_t mode_hsync_start;
    uint16_t mode_hsync_end;
    uint16_t mode_htotal;
    uint16_t mode_hskew;
    uint16_t mode_vdisplay;
    uint16_t mode_vsync_start;
    uint16_t mode_vsync_end;
    uint16_t mode_vtotal;
    uint16_t mode_vscan;
    uint32_t mode_flags;
};

struct drm_mode_get_plane {
    uint32_t plane_id;
    uint32_t crtc_id;
    uint32_t fb_id;
    uint32_t crtc_x, crtc_y;
    uint32_t x, y;
    uint32_t possible_crtcs;
    uint32_t gamma_size;
    uint32_t count_format_types;
    uint64_t format_type_ptr;
};

/* DRM framebuffer（保留定义供参考，当前路径不直接使用 GETFB） */
struct drm_prime_handle {
    uint32_t handle;
    uint32_t flags;
    int32_t  fd;
};

struct drm_gem_close_ { uint32_t handle; uint32_t pad; };

/* ============================================================
 * 2. 全局状态
 * ============================================================ */

static volatile sig_atomic_t g_stop = 0;
static void on_signal(int sig) { (void)sig; g_stop = 1; }

enum bufmode { MODE_DMABUF = 0, MODE_MMAP, MODE_IONREAD };

struct buf {
    int      dmabuf_fd;      /* dma-buf fd（DMABUF 模式用） */
    size_t   length;
    void    *map;            /* mmap 得到的地址（可读像素） */
    int      queued;
};

/* ============================================================
 * 3. 工具函数
 * ============================================================ */

static void die(const char *what, int code)
{
    fprintf(stderr, "%s: %s\n", what, strerror(errno));
    exit(code);
}

static const char *fourcc_str(uint32_t f, char out[5])
{
    out[0] = f & 0xff; out[1] = (f >> 8) & 0xff;
    out[2] = (f >> 16) & 0xff; out[3] = (f >> 24) & 0xff;
    out[4] = 0;
    return out;
}

static long now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000L + ts.tv_nsec / 1000000L;
}

/* ============================================================
 * 4. DRM：找到 1080x2160 的 scanout framebuffer 并导出为 dma-buf
 * ============================================================ */

/*
 * 从 DRM 找到 1080x2160 的 scanout framebuffer，并导出为 dma-buf fd。
 * 返回 dma-buf fd；失败返回 -1。
 *
 * 路径与第三方一致：
 *   GETRESOURCES → 枚举 crtc 列表
 *   GETCRTC      → 读 crtc->fb_id（并校验 1080x2160x32bpp）
 *   PRIME_HANDLE_TO_FD → 导出 dma-buf
 *
 * 说明：CRTC 结构里的 mode_hdisplay/mode_vdisplay 是当前显示时序，
 * 用它做尺寸校验；bpp 若不可得则放宽为仅校验分辨率。
 */
static int drm_find_scanout_dmabuf(int fd, uint32_t want_w, uint32_t want_h,
                                   uint32_t *out_pitch)
{
    struct drm_mode_card_res res;
    uint32_t *crtc_ids = NULL;
    int ret = -1;

    memset(&res, 0, sizeof(res));
    if (ioctl(fd, DRM_IOCTL_MODE_GETRESOURCES, &res) < 0)
        die("drm GETRESOURCES", 4);

    fprintf(stderr, "drm: %u crtc(s), %u fb(s)\n",
            res.count_crtcs, res.count_fbs);

    if (res.count_crtcs == 0) {
        fprintf(stderr, "drm: no crtc reported\n");
        return -1;
    }

    /* 第二次调用取得 crtc id 数组 */
    crtc_ids = calloc(res.count_crtcs, sizeof(uint32_t));
    if (!crtc_ids) die("calloc crtc_ids", 5);

    {
        struct drm_mode_card_res res2;
        memset(&res2, 0, sizeof(res2));
        res2.crtc_id_ptr    = (uint64_t)(uintptr_t)crtc_ids;
        res2.count_crtcs    = res.count_crtcs;
        /* 其余 count 置 0，只取 crtc */
        if (ioctl(fd, DRM_IOCTL_MODE_GETRESOURCES, &res2) < 0) {
            fprintf(stderr, "drm: GETRESOURCES(crtcs) failed: %s\n",
                    strerror(errno));
            free(crtc_ids);
            return -1;
        }
    }

    for (uint32_t i = 0; i < res.count_crtcs; i++) {
        struct drm_mode_get_crtc c;
        memset(&c, 0, sizeof(c));
        c.crtc_id = crtc_ids[i];

        if (ioctl(fd, DRM_IOCTL_MODE_GETCRTC, &c) < 0) {
            fprintf(stderr, "drm: GETCRTC(id=%u) failed: %s\n",
                    crtc_ids[i], strerror(errno));
            continue;
        }

        fprintf(stderr,
                "drm: crtc[%u] id=%u fb_id=%u mode=%ux%u valid=%u\n",
                i, c.crtc_id, c.fb_id,
                c.mode_hdisplay, c.mode_vdisplay, c.mode_valid);

        if (!c.fb_id)
            continue;

        if (c.mode_valid &&
            (c.mode_hdisplay != want_w || c.mode_vdisplay != want_h))
            continue;

        if (!c.mode_valid) {
            fprintf(stderr, "drm: crtc[%u] has fb but no valid mode, "
                            "trying anyway\n", i);
        }

        /*
         * 导出：需要 GEM handle。旧内核里 crtc->fb_id 对应的 handle
         * 可通过 PRIME_HANDLE_TO_FD 直接对 fb_id 尝试（部分 msm 实现
         * 接受 fb_id 作为 handle），失败则用 GETPLANE 拿 handle。
         */
        {
            struct drm_prime_handle ph;
            memset(&ph, 0, sizeof(ph));
            ph.handle = c.fb_id;
            ph.fd     = -1;

            if (ioctl(fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &ph) == 0) {
                fprintf(stderr,
                        "drm: exported fb_id=%u (%ux%u) as dma-buf fd=%d\n",
                        c.fb_id, c.mode_hdisplay, c.mode_vdisplay, ph.fd);
                if (out_pitch) *out_pitch = want_w * 4;
                ret = ph.fd;
                break;
            }
            fprintf(stderr, "drm: PRIME_HANDLE_TO_FD(fb_id=%u) failed: %s\n",
                    c.fb_id, strerror(errno));
        }

        /* 回退：用 GETPLANE 拿 plane 的 fb_id，再导出 */
        {
            struct drm_mode_get_plane p;
            memset(&p, 0, sizeof(p));
            uint32_t plane_ids[16];
            struct drm_mode_card_res pres;
            memset(&pres, 0, sizeof(pres));

            /* 没有 count_planes 字段，直接用 GETPLANE 探测 plane_id
             * 1..N；msm 通常从 1 开始。这里只试少量几个。 */
            for (uint32_t pid = 1; pid <= 8; pid++) {
                memset(&p, 0, sizeof(p));
                p.plane_id = pid;
                if (ioctl(fd, DRM_IOCTL_MODE_GETPLANE, &p) < 0)
                    continue;
                if (!p.fb_id)
                    continue;

                struct drm_prime_handle ph;
                memset(&ph, 0, sizeof(ph));
                ph.handle = p.fb_id;
                ph.fd     = -1;
                if (ioctl(fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &ph) == 0) {
                    fprintf(stderr,
                            "drm: plane %u fb_id=%u exported as fd=%d\n",
                            pid, p.fb_id, ph.fd);
                    if (out_pitch) *out_pitch = want_w * 4;
                    ret = ph.fd;
                    goto out;
                }
            }
            (void)plane_ids; (void)pres;
        }
    }

out:
    free(crtc_ids);
    if (ret < 0)
        fprintf(stderr, "no %ux%u scanout framebuffer found\n", want_w, want_h);
    return ret;
}

/* ============================================================
 * 5. ION：分配目标 buffer 并导出 dma-buf
 * ============================================================ */

static int ion_alloc_dmabuf(int ion_fd, size_t len, int *out_fd)
{
    struct ion_heap_query q;
    struct ion_heap_data *heaps = NULL;
    unsigned int heap_mask = 0;

    memset(&q, 0, sizeof(q));
    if (ioctl(ion_fd, ION_IOC_HEAP_QUERY, &q) < 0) {
        fprintf(stderr, "ion: HEAP_QUERY(count) failed: %s\n", strerror(errno));
        return -1;
    }

    fprintf(stderr, "ion: %u heap(s)\n", q.cnt);
    if (q.cnt) {
        heaps = calloc(q.cnt, sizeof(struct ion_heap_data));
        if (!heaps) die("calloc heaps", 6);
        q.heaps = (uint64_t)(uintptr_t)heaps;
        if (ioctl(ion_fd, ION_IOC_HEAP_QUERY, &q) < 0) {
            fprintf(stderr, "ion: HEAP_QUERY(data) failed: %s\n", strerror(errno));
            free(heaps);
            return -1;
        }
        for (unsigned int i = 0; i < q.cnt; i++) {
            fprintf(stderr, "ion: heap[%u] name=\"%s\" type=%u id=%u\n",
                    i, heaps[i].name, heaps[i].type, heaps[i].heap_id);
            if (strcmp(heaps[i].name, "system") == 0)
                heap_mask = 1u << heaps[i].heap_id;
        }
        free(heaps);
    }

    if (!heap_mask) {
        fprintf(stderr, "ion: system heap not found, falling back to mask=1\n");
        heap_mask = 1;
    } else {
        fprintf(stderr, "ion: using system heap mask=0x%x\n", heap_mask);
    }

    struct ion_allocation_data ad;
    memset(&ad, 0, sizeof(ad));
    ad.len          = len;
    ad.align        = 4096;
    ad.heap_id_mask = heap_mask;
    ad.flags        = 0;

    if (ioctl(ion_fd, ION_IOC_ALLOC, &ad) < 0) {
        fprintf(stderr, "ion: ALLOC(%zu) failed: %s\n", len, strerror(errno));
        return -1;
    }

    struct ion_fd_data fd_data;
    memset(&fd_data, 0, sizeof(fd_data));
    fd_data.handle = ad.handle;

    if (ioctl(ion_fd, ION_IOC_SHARE, &fd_data) < 0) {
        fprintf(stderr, "ion: SHARE failed: %s\n", strerror(errno));
        return -1;
    }

    fprintf(stderr, "ion: allocated %zu bytes, dma-buf fd=%d\n", len, fd_data.fd);
    *out_fd = fd_data.fd;
    return 0;
}

/* ============================================================
 * 6. 主程序
 * ============================================================ */

int main(int argc, char **argv)
{
    int fps = 20;
    enum bufmode mode = MODE_DMABUF;
    uint32_t src_w = SRC_W, src_h = SRC_H;
    uint32_t dst_w = DST_W, dst_h = DST_H;
    int card_fd = -1, video_fd = -1, ion_fd = -1;
    int src_dmabuf = -1, dst_dmabuf = -1;
    struct buf src[NUM_BUFS], dst[NUM_BUFS];
    size_t dst_len, src_len;
    int ret_code = 0;
    uint64_t captured = 0;
    char f1[5], f2[5];

    memset(src, 0, sizeof(src));
    memset(dst, 0, sizeof(dst));
    for (int i = 0; i < NUM_BUFS; i++) { src[i].dmabuf_fd = -1; dst[i].dmabuf_fd = -1; }

    /* ---- 参数解析 ---- */
    if (argc > 1 && argv[1][0] != '-') {
        int v = atoi(argv[1]);
        if (v > 0) fps = v;
    }
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            /* 只打印用法后退出，不做任何设备操作。
             * start-native.sh 用它做「二进制能否被 exec」的前置检查。 */
            fprintf(stderr,
                "%s: C3 sde_rotator capture -> stdout (self-authored, correct dmabuf import)\n"
                "usage: %s [FPS] [--mode=dmabuf|mmap] [--width=W] [--height=H]\n"
                "  default: fps=%d mode=%s dst=%ux%u src=%ux%u\n"
                "build: %s %s\n",
                argv[0], argv[0], fps,
                mode == MODE_MMAP ? "mmap" : (mode == MODE_IONREAD ? "ionread" : "dmabuf"),
                dst_w, dst_h, src_w, src_h, __DATE__, __TIME__);
            return 0;
        }
        if (strcmp(argv[i], "--version") == 0) {
            fprintf(stderr, "sde_rotator_stream2 %s %s\n", __DATE__, __TIME__);
            return 0;
        }
        if (strncmp(argv[i], "--mode=", 7) == 0) {
            const char *m = argv[i] + 7;
            if (strcmp(m, "mmap") == 0)         mode = MODE_MMAP;
            else if (strcmp(m, "ionread") == 0) mode = MODE_IONREAD;
            else                                mode = MODE_DMABUF;
        } else if (strncmp(argv[i], "--width=", 8) == 0) {
            dst_w = (uint32_t)atoi(argv[i] + 8);
        } else if (strncmp(argv[i], "--height=", 9) == 0) {
            dst_h = (uint32_t)atoi(argv[i] + 9);
        }
    }

    signal(SIGINT,  on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGPIPE, SIG_IGN);

    /* ---- 打开设备 ---- */
    card_fd = open(DEV_CARD0, O_RDWR | O_CLOEXEC);
    if (card_fd < 0) die("open " DEV_CARD0, 2);

    video_fd = open(DEV_VIDEO, O_RDWR | O_CLOEXEC);
    if (video_fd < 0) die("open " DEV_VIDEO, 3);

    /* ---- 查询 rotator 能力（重要：确认支持的 memory 类型） ---- */
    struct v4l2_capability cap;
    memset(&cap, 0, sizeof(cap));
    if (ioctl(video_fd, VIDIOC_QUERYCAP, &cap) == 0) {
        fprintf(stderr, "video2: driver=\"%s\" card=\"%s\" bus=\"%s\" caps=0x%x\n",
                cap.driver, cap.card, cap.bus_info, cap.capabilities);
        fprintf(stderr, "video2: READWRITE=%d STREAMING=%d\n",
                !!(cap.capabilities & V4L2_CAP_READWRITE),
                !!(cap.capabilities & V4L2_CAP_STREAMING));
        fprintf(stderr, "video2: MEM2MEM=%d\n",
                !!(cap.capabilities & V4L2_CAP_VIDEO_M2M_MPLANE));
    }

    /* ---- 打印 streamoff 前的状态（若有残留会话） ---- */
    {
        enum v4l2_buf_type t = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        ioctl(video_fd, VIDIOC_STREAMOFF, &t);
        t = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        ioctl(video_fd, VIDIOC_STREAMOFF, &t);
    }

    /* ---- 设置源格式 ---- */
    struct v4l2_format fmt;
    memset(&fmt, 0, sizeof(fmt));
    fmt.type                = V4L2_BUF_TYPE_VIDEO_OUTPUT;
    fmt.fmt.pix.width       = src_w;
    fmt.fmt.pix.height      = src_h;
    fmt.fmt.pix.pixelformat = SRC_FOURCC;
    fmt.fmt.pix.field       = V4L2_FIELD_NONE;
    if (ioctl(video_fd, VIDIOC_S_FMT, &fmt) < 0) die("set QRGB source", 4);

    src_len = fmt.fmt.pix.sizeimage;
    fprintf(stderr,
            "source=%ux%u pitch=%u size=%u fourcc=%s\n",
            fmt.fmt.pix.width, fmt.fmt.pix.height,
            fmt.fmt.pix.bytesperline, fmt.fmt.pix.sizeimage,
            fourcc_str(fmt.fmt.pix.pixelformat, f1));

    /* ---- 设置目标格式 ---- */
    memset(&fmt, 0, sizeof(fmt));
    fmt.type                = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    fmt.fmt.pix.width       = dst_w;
    fmt.fmt.pix.height      = dst_h;
    fmt.fmt.pix.pixelformat = DST_FOURCC;
    fmt.fmt.pix.field       = V4L2_FIELD_NONE;
    if (ioctl(video_fd, VIDIOC_S_FMT, &fmt) < 0) die("set XRGB destination", 7);

    dst_len = fmt.fmt.pix.sizeimage;
    fprintf(stderr,
            "destination=%ux%u pitch=%u size=%u fourcc=%s\n",
            fmt.fmt.pix.width, fmt.fmt.pix.height,
            fmt.fmt.pix.bytesperline, fmt.fmt.pix.sizeimage,
            fourcc_str(fmt.fmt.pix.pixelformat, f2));

    fprintf(stderr, "fps=%d mode=%s\n", fps,
            mode == MODE_DMABUF  ? "dmabuf" :
            mode == MODE_MMAP    ? "mmap"   : "ionread");

    /* ============================================================
     * 准备 buffer
     * ============================================================ */
    if (mode == MODE_MMAP) {
        /* ---- 纯标准路径：让驱动分配 ---- */
        struct v4l2_requestbuffers rb;
        memset(&rb, 0, sizeof(rb));
        rb.count  = NUM_BUFS;
        rb.type   = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        rb.memory = V4L2_MEMORY_MMAP;
        if (ioctl(video_fd, VIDIOC_REQBUFS, &rb) < 0) die("REQBUFS OUTPUT", 8);

        for (int i = 0; i < NUM_BUFS; i++) {
            struct v4l2_buffer b;
            memset(&b, 0, sizeof(b));
            b.type   = V4L2_BUF_TYPE_VIDEO_OUTPUT;
            b.memory = V4L2_MEMORY_MMAP;
            b.index  = i;
            if (ioctl(video_fd, VIDIOC_QUERYBUF, &b) < 0) die("QUERYBUF OUTPUT", 8);
            src[i].length = b.length;
            src[i].map = mmap(NULL, b.length, PROT_READ | PROT_WRITE,
                              MAP_SHARED, video_fd, b.m.offset);
            if (src[i].map == MAP_FAILED) die("mmap source", 8);
        }

        memset(&rb, 0, sizeof(rb));
        rb.count  = NUM_BUFS;
        rb.type   = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        rb.memory = V4L2_MEMORY_MMAP;
        if (ioctl(video_fd, VIDIOC_REQBUFS, &rb) < 0) die("REQBUFS CAPTURE", 8);

        for (int i = 0; i < NUM_BUFS; i++) {
            struct v4l2_buffer b;
            memset(&b, 0, sizeof(b));
            b.type   = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            b.memory = V4L2_MEMORY_MMAP;
            b.index  = i;
            if (ioctl(video_fd, VIDIOC_QUERYBUF, &b) < 0) die("QUERYBUF CAPTURE", 8);
            dst[i].length = b.length;
            dst[i].map = mmap(NULL, b.length, PROT_READ | PROT_WRITE,
                              MAP_SHARED, video_fd, b.m.offset);
            if (dst[i].map == MAP_FAILED) die("mmap destination", 8);
        }
    } else {
        /* ---- dma-buf 路径 ---- */
        ion_fd = open(DEV_ION, O_RDWR | O_CLOEXEC);
        if (ion_fd < 0) die("open " DEV_ION, 8);

        /* 源：从 DRM 导出 scanout fb 的 dma-buf */
        src_dmabuf = drm_find_scanout_dmabuf(card_fd, src_w, src_h, NULL);
        if (src_dmabuf < 0) {
            fprintf(stderr, "fatal: cannot obtain source dma-buf\n");
            return 11;
        }

        /* 目标：ION 分配 */
        dst_len = (size_t)dst_w * dst_h * 4;
        fprintf(stderr, "destination buffer length=%zu\n", dst_len);
        if (ion_alloc_dmabuf(ion_fd, dst_len, &dst_dmabuf) < 0) {
            fprintf(stderr, "fatal: cannot allocate destination dma-buf\n");
            return 9;
        }

        /* mmap 目标以便读取像素 */
        for (int i = 0; i < NUM_BUFS; i++) {
            dst[i].dmabuf_fd = dst_dmabuf;
            dst[i].length    = dst_len;
            dst[i].map = mmap(NULL, dst_len, PROT_READ | PROT_WRITE,
                              MAP_SHARED, dst_dmabuf, 0);
            if (dst[i].map == MAP_FAILED) {
                fprintf(stderr, "mmap destination failed: %s\n", strerror(errno));
                return 10;
            }
            src[i].dmabuf_fd = src_dmabuf;
            src[i].length    = src_len;
        }

        /* 通知驱动 buffer 数量（rotator 用私有 ioctl，若失败不致命） */
        struct v4l2_requestbuffers rb;
        memset(&rb, 0, sizeof(rb));
        rb.count  = NUM_BUFS;
        rb.type   = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        rb.memory = V4L2_MEMORY_DMABUF;
        if (ioctl(video_fd, VIDIOC_REQBUFS, &rb) < 0)
            fprintf(stderr, "note: REQBUFS(DMABUF,OUTPUT) rejected: %s\n",
                    strerror(errno));

        memset(&rb, 0, sizeof(rb));
        rb.count  = NUM_BUFS;
        rb.type   = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        rb.memory = V4L2_MEMORY_DMABUF;
        if (ioctl(video_fd, VIDIOC_REQBUFS, &rb) < 0)
            fprintf(stderr, "note: REQBUFS(DMABUF,CAPTURE) rejected: %s\n",
                    strerror(errno));
    }

    /* ============================================================
     * 入队 + 启动
     * ============================================================ */
    for (int i = 0; i < NUM_BUFS; i++) {
        struct v4l2_buffer b;

        memset(&b, 0, sizeof(b));
        b.type   = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        b.memory = (mode == MODE_MMAP) ? V4L2_MEMORY_MMAP : V4L2_MEMORY_DMABUF;
        b.index  = i;
        if (mode == MODE_MMAP) { b.m.userptr = 0; b.length = src[i].length; }
        else                   { b.m.fd = src[i].dmabuf_fd; b.length = src[i].length; }
        b.bytesused = b.length;
        if (ioctl(video_fd, VIDIOC_QBUF, &b) < 0) {
            fprintf(stderr, "QBUF source[%d] failed: %s\n", i, strerror(errno));
            return 12;
        }

        memset(&b, 0, sizeof(b));
        b.type   = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        b.memory = (mode == MODE_MMAP) ? V4L2_MEMORY_MMAP : V4L2_MEMORY_DMABUF;
        b.index  = i;
        if (mode == MODE_MMAP) { b.m.userptr = 0; b.length = dst[i].length; }
        else                   { b.m.fd = dst[i].dmabuf_fd; b.length = dst[i].length; }
        b.bytesused = b.length;
        if (ioctl(video_fd, VIDIOC_QBUF, &b) < 0) {
            fprintf(stderr, "QBUF destination[%d] failed: %s\n", i, strerror(errno));
            return 13;
        }
        src[i].queued = dst[i].queued = 1;
    }

    {
        enum v4l2_buf_type t = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        if (ioctl(video_fd, VIDIOC_STREAMON, &t) < 0) die("stream on capture", 14);
        t = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        if (ioctl(video_fd, VIDIOC_STREAMON, &t) < 0) die("stream on output", 15);
    }

    /* ============================================================
     * 主循环
     * ============================================================ */
    {
        long next = now_ms();
        const long period = 1000L / fps;
        int err_count = 0;

        while (!g_stop) {
            struct pollfd pfd = { .fd = video_fd, .events = POLLIN | POLLERR };
            int pr = poll(&pfd, 1, 2000);
            if (pr < 0) {
                if (errno == EINTR) continue;
                fprintf(stderr, "rotator poll: %s\n", strerror(errno));
                ret_code = 15;
                break;
            }
            if (pr == 0) {
                fprintf(stderr, "rotator poll: timeout\n");
                ret_code = 16;
                break;
            }

            struct v4l2_buffer b;
            memset(&b, 0, sizeof(b));
            b.type   = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            b.memory = (mode == MODE_MMAP) ? V4L2_MEMORY_MMAP : V4L2_MEMORY_DMABUF;

            if (ioctl(video_fd, VIDIOC_DQBUF, &b) < 0) {
                if (errno == EAGAIN) { usleep(2000); continue; }
                fprintf(stderr, "rotator DQBUF: %s\n", strerror(errno));
                ret_code = 17;
                break;
            }

            if (b.flags & V4L2_BUF_FLAG_ERROR) {
                fprintf(stderr, "rotator frame error flags=0x%x\n", b.flags);
                if (++err_count >= 3) { ret_code = 17; break; }
                /* 重新入队再试 */
                b.flags = 0;
                if (ioctl(video_fd, VIDIOC_QBUF, &b) < 0) { ret_code = 18; break; }
                continue;
            }

            /* ---- 成功拿到一帧：输出像素 ---- */
            int idx = b.index;
            size_t n = b.bytesused ? b.bytesused : dst[idx].length;
            if (n > 0 && dst[idx].map) {
                if (fwrite(dst[idx].map, 1, n, stdout) != n) {
                    fprintf(stderr, "fwrite: %s\n", strerror(errno));
                    ret_code = 19;
                    break;
                }
                fflush(stdout);
                captured++;
                if (captured == 1 || captured % fps == 0)
                    fprintf(stderr, "captured=%llu\n",
                            (unsigned long long)captured);
            }

            /* 重新入队 */
            b.flags = 0;
            if (ioctl(video_fd, VIDIOC_QBUF, &b) < 0) {
                fprintf(stderr, "requeue failed: %s\n", strerror(errno));
                ret_code = 18;
                break;
            }

            /* 限速 */
            next += period;
            long d = next - now_ms();
            if (d > 0) {
                struct timespec ts = { .tv_sec = d / 1000,
                                       .tv_nsec = (d % 1000) * 1000000L };
                clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, NULL);
            } else {
                next = now_ms();
            }
        }
    }

    /* ============================================================
     * 清理
     * ============================================================ */
    {
        enum v4l2_buf_type t = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        ioctl(video_fd, VIDIOC_STREAMOFF, &t);
        t = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        ioctl(video_fd, VIDIOC_STREAMOFF, &t);
    }

    for (int i = 0; i < NUM_BUFS; i++) {
        if (dst[i].map && mode == MODE_DMABUF) munmap(dst[i].map, dst[i].length);
        else if (dst[i].map && mode == MODE_MMAP) munmap(dst[i].map, dst[i].length);
        if (src[i].map) munmap(src[i].map, src[i].length);
    }
    if (video_fd >= 0) close(video_fd);
    if (card_fd  >= 0) close(card_fd);
    if (ion_fd   >= 0) close(ion_fd);

    fprintf(stderr, "captured=%llu total, exit=%d\n",
            (unsigned long long)captured, ret_code);
    return ret_code;
}
