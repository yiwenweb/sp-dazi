#!/bin/sh
set -eu

PACKAGE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BASE=/data/local/tmp/c3-screen-stream-v2

pkill -f "^python3 $BASE/touch_proxy.py" 2>/dev/null || true
pkill -f "^$BASE/bin/weston_tiny_guard" 2>/dev/null || true
pkill -f "^/bin/sh $BASE/start-native.sh" 2>/dev/null || true
# 同时清掉旧名与新名（历史版本里叫 sde_rotator_stream2）
sudo -n pkill -f "^$BASE/bin/sde_rotator_stream" 2>/dev/null || true
sudo -n pkill -f "sde_rotator_stream2" 2>/dev/null || true
pkill -f "^$BASE/bin/swscale_xrgb_to_nv12" 2>/dev/null || true
sudo -n pkill -f "^$BASE/bin/v4l_h264_encoder" 2>/dev/null || true

mkdir -p "$BASE/bin"
for name in sde_rotator_stream swscale_xrgb_to_nv12 v4l_h264_encoder weston_tiny_guard; do
  cp "$PACKAGE_DIR/bin/$name" "$BASE/bin/$name.new"
  chmod 755 "$BASE/bin/$name.new"
  mv -f "$BASE/bin/$name.new" "$BASE/bin/$name"
done
for name in start-native.sh touch_proxy.py; do
  cp "$PACKAGE_DIR/$name" "$BASE/$name.new"
  chmod 755 "$BASE/$name.new"
  mv -f "$BASE/$name.new" "$BASE/$name"
done
printf '%s\n' 'c3-mirror-v5-4-0-dmabuf' > "$BASE/VERSION"

sudo -n rm -f /dev/shm/c3-frame-signatures.bin /dev/shm/c3-capture-trace.log \
  /dev/shm/c3-encoder-trace.log
nohup env XDG_RUNTIME_DIR=/var/tmp/weston "$BASE/bin/weston_tiny_guard" \
  </dev/null >"$BASE/tiny-guard.log" 2>&1 &
nohup python3 "$BASE/touch_proxy.py" </dev/null >"$BASE/touch.log" 2>&1 &
nohup env FPS=20 BITRATE=5000000 "$BASE/start-native.sh" \
  </dev/null >"$BASE/launcher.log" 2>&1 &
sleep 1

