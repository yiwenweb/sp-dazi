#!/bin/sh
# ============================================================
# build_and_test.sh —— 在 C3 上编译/自检/试跑自研版 sde_rotator_stream2
#
# 用法（在 C3 上）：
#   sh build_and_test.sh
#
# 逻辑：
#   1. 优先用 C3 原生 gcc 编译（会使用设备自己的 ioctl 头文件，
#      能暴露头文件与内核不一致的问题）
#   2. 若原生编译失败 → 回退使用随包上传的已交叉编译静态二进制
#      （本机 WSL 编译，sha256 379391da...，无 glibc 依赖）
#   3. 打印 rotator 设备能力（确认支持的 memory 类型）
#   4. 依次用 dmabuf / mmap 两种模式试跑，报告结果
# ============================================================
set -u

BASE=/data/local/tmp/c3-screen-stream-v2
SRC_DIR=${1:-$BASE}
OUT=$BASE/bin/sde_rotator_stream2
PRECOMPILED=$SRC_DIR/sde_rotator_stream2

echo "=============================================="
echo " 1. 编译（优先原生，失败则用预编译）"
echo "=============================================="
cd "$SRC_DIR" || { echo "无法进入 $SRC_DIR"; exit 1; }

BUILT=0
if command -v gcc >/dev/null 2>&1; then
  echo "--- 尝试 C3 原生 gcc 编译 ---"
  gcc -O2 -Wall -Wextra -o /tmp/sde_rotator_stream2 sde_rotator_stream2.c -lm 2>&1
  rc=$?
  if [ $rc -eq 0 ]; then
    echo "原生编译成功。"
    cp /tmp/sde_rotator_stream2 "$OUT"
    BUILT=1
  else
    echo ""
    echo "!!! 原生编译失败 (exit=$rc)"
    echo "!!! 这本身是有价值的信息：说明 C3 的 ioctl 头文件与源码预期不一致。"
    echo "!!! 请把上面的错误贴出来，但先继续用预编译二进制试跑。"
  fi
else
  echo "未找到 gcc，跳过原生编译。"
fi

if [ $BUILT -eq 0 ]; then
  if [ -f "$PRECOMPILED" ] && [ -s "$PRECOMPILED" ]; then
    echo "--- 使用随包上传的预编译静态二进制 ---"
    cp "$PRECOMPILED" "$OUT"
  elif [ -f /tmp/sde2_static ]; then
    echo "--- 使用 /tmp/sde2_static ---"
    cp /tmp/sde2_static "$OUT"
  else
    echo "错误：既无法原生编译，也找不到预编译二进制。"
    exit 1
  fi
fi

chmod 755 "$OUT"
echo "可执行文件 -> $OUT"
ls -la "$OUT"
echo "sha256: $(sha256sum "$OUT" 2>/dev/null | cut -d' ' -f1)"

echo ""
echo "=============================================="
echo " 2. 设备能力查询"
echo "=============================================="
echo "--- rotator 设备节点 ---"
ls -la /dev/video* 2>/dev/null
echo "--- 设备名 ---"
for f in /sys/class/video4linux/*/name; do
  [ -f "$f" ] && echo "  $f: $(cat $f)"
done
echo "--- DRM 节点 ---"
ls -la /dev/dri/ 2>/dev/null
echo "--- ION 节点 ---"
ls -la /dev/ion 2>/dev/null || echo "  /dev/ion 不存在"

echo ""
echo "=============================================="
echo " 3. 试跑：mode=dmabuf（推荐路径）"
echo "=============================================="
echo "--- 运行前 SDEROT_ERR 计数 ---"
sudo -n dmesg 2>/dev/null | grep -c 'SDEROT_ERR' || echo "0"

timeout 6 sudo -n "$OUT" 2 --mode=dmabuf > /tmp/rot2_dmabuf.bin 2>/tmp/rot2_dmabuf.err
echo "exit=$?  输出字节=$(wc -c < /tmp/rot2_dmabuf.bin)"
echo "--- stderr ---"
cat /tmp/rot2_dmabuf.err

echo ""
echo "--- 运行后 SDEROT_ERR 计数 ---"
sudo -n dmesg 2>/dev/null | grep -c 'SDEROT_ERR' || echo "0"

echo ""
echo "=============================================="
echo " 4. 试跑：mode=mmap（纯标准路径）"
echo "=============================================="
timeout 6 sudo -n "$OUT" 2 --mode=mmap > /tmp/rot2_mmap.bin 2>/tmp/rot2_mmap.err
echo "exit=$?  输出字节=$(wc -c < /tmp/rot2_mmap.bin)"
echo "--- stderr ---"
cat /tmp/rot2_mmap.err

echo ""
echo "=============================================="
echo " 5. 结果摘要"
echo "=============================================="
for m in dmabuf mmap; do
  sz=$(wc -c < /tmp/rot2_$m.bin)
  if [ "$sz" -gt 0 ]; then
    echo "  [$m] 成功   输出 $sz 字节"
  else
    echo "  [$m] 失败   输出 0 字节"
  fi
done
echo ""
echo "若两种模式都输出 0 字节，请把上面完整输出贴出来。"
