#!/usr/bin/env python3
import os
import socket
import struct
import threading
import time
import fcntl

EV_SYN, EV_KEY, EV_ABS = 0, 1, 3
SYN_REPORT, BTN_TOUCH = 0, 0x14A
ABS_X, ABS_Y, ABS_PRESSURE = 0x00, 0x01, 0x18
ABS_MT_SLOT, ABS_MT_TOUCH_MAJOR, ABS_MT_TOUCH_MINOR = 0x2F, 0x30, 0x31
ABS_MT_POSITION_X, ABS_MT_POSITION_Y, ABS_MT_TRACKING_ID = 0x35, 0x36, 0x39
ABS_MT_PRESSURE = 0x3A

PHYSICAL_TOUCH = '/dev/input/event2'
out_fd = -1

if os.path.exists(PHYSICAL_TOUCH):
  try:
    out_fd = os.open(PHYSICAL_TOUCH, os.O_WRONLY | os.O_NONBLOCK)
    print('>>> 成功绑定物理触摸屏:', PHYSICAL_TOUCH)
  except Exception:
    out_fd = -1

if out_fd < 0:
  try:
    ufd = os.open('/dev/uinput', os.O_WRONLY | os.O_NONBLOCK)
    fcntl.ioctl(ufd, 0x40045564, 1)
    fcntl.ioctl(ufd, 0x40045564, 3)
    fcntl.ioctl(ufd, 0x40045564, 0)
    fcntl.ioctl(ufd, 0x40045565, 0x14A)
    for axis in (0x00, 0x01, 0x18, 0x2F, 0x30, 0x31, 0x35, 0x36, 0x39, 0x3A):
      fcntl.ioctl(ufd, 0x40045567, axis)
    
    name = ('virtual_c3_touchscreen'.encode('utf-8') + bytes(80))[:80]
    input_id = struct.pack('HHHH', 0x0019, 0x0001, 0x0001, 0x0001)
    ff_max = struct.pack('i', 0)
    absmax, absmin, absfuzz, absflat = [0]*64, [0]*64, [0]*64, [0]*64

    absmax[0] = 1080
    absmax[0x35] = 1080
    absmax[1] = 2160
    absmax[0x36] = 2160
    absmax[0x18] = 255
    absmax[0x3A] = 255
    absmax[0x30] = 255
    absmax[0x31] = 255
    absmax[0x2F] = 9
    absmax[0x39] = 65535

    user_dev = name + input_id + ff_max + struct.pack('64i', *absmax) + struct.pack('64i', *absmin) + struct.pack('64i', *absfuzz) + struct.pack('64i', *absflat)
    os.write(ufd, user_dev)
    fcntl.ioctl(ufd, 0x5501)
    out_fd = ufd
    print('>>> 纯内核虚拟多点触摸屏创建成功 (零第三方库依赖)！')
  except Exception as e:
    print(f'❌ 内核虚拟屏幕创建失败: {e}')

def emit(event_type, code, value):
  if out_fd >= 0:
    try:
      os.write(out_fd, struct.pack('@llHHi', 0, 0, event_type, code, value))
    except Exception:
      pass

def sync():
  emit(EV_SYN, SYN_REPORT, 0)

def scale(value, source_max, target_max):
  return max(0, min(target_max, round(value * target_max / source_max)))

def read_exact(sock, size):
  data = bytearray()
  while len(data) < size:
    chunk = sock.recv(size - len(data))
    if not chunk:
      return None
    data.extend(chunk)
  return bytes(data)

def handle(client):
  client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
  tracking_id = 100
  try:
    while True:
      message = read_exact(client, 32)
      if message is None:
        return
      msg_type, action, _, x, y, width, height, _, _, _ = struct.unpack('>BBQIIHHHII', message)
      if msg_type == 0x7F:
        client.sendall(struct.pack('>Q', time.monotonic_ns() // 1000))
        continue
      if msg_type != 2 or width < 2 or height < 2:
        continue
      raw_x = 1080 - scale(y, height - 1, 1080)
      raw_y = scale(x, width - 1, 2160)
      emit(EV_ABS, ABS_MT_SLOT, 0)
      if action == 0:
        tracking_id = (tracking_id + 1) & 0xFFFF
        emit(EV_ABS, ABS_MT_TRACKING_ID, tracking_id)
        emit(EV_ABS, ABS_MT_POSITION_X, raw_x)
        emit(EV_ABS, ABS_MT_POSITION_Y, raw_y)
        emit(EV_ABS, ABS_MT_TOUCH_MAJOR, 20)
        emit(EV_ABS, ABS_MT_TOUCH_MINOR, 20)
        emit(EV_ABS, ABS_MT_PRESSURE, 120)
        emit(EV_ABS, ABS_X, raw_x)
        emit(EV_ABS, ABS_Y, raw_y)
        emit(EV_ABS, ABS_PRESSURE, 120)
        emit(EV_KEY, BTN_TOUCH, 1)
      elif action == 2:
        emit(EV_ABS, ABS_MT_POSITION_X, raw_x)
        emit(EV_ABS, ABS_MT_POSITION_Y, raw_y)
        emit(EV_ABS, ABS_X, raw_x)
        emit(EV_ABS, ABS_Y, raw_y)
      elif action in (1, 3):
        emit(EV_ABS, ABS_MT_PRESSURE, 0)
        emit(EV_ABS, ABS_MT_TRACKING_ID, -1)
        emit(EV_ABS, ABS_PRESSURE, 0)
        emit(EV_KEY, BTN_TOUCH, 0)
      sync()
  finally:
    client.close()

listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
listener.bind(('0.0.0.0', 27184))
listener.listen(3)
print('>>> 触控代理已就绪，正在监听 27184 端口...')
while True:
  client, _ = listener.accept()
  threading.Thread(target=handle, args=(client,), daemon=True).start()
